- Hey bro! Hint is here, come on~!
- Have u found the secret in color?
- If not, maybe u need to understand the nature of color.
- What r u waiting for? Hurry up!

---

+ Let's go to the amusement park!
+ I bought three tickets. 
+ There are three adjacent seats. They are E, F, and G.
+ Which seat would you like to take?
+ G? Yes, I think the seat G is the best!
+ Okay! And now, we shall set off!

